# Foo

Sample specification for JUnit3 example.