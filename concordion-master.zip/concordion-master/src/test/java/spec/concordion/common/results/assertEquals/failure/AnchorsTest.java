package spec.concordion.common.results.assertEquals.failure;

import org.concordion.integration.junit4.ConcordionRunner;
import org.junit.runner.RunWith;

@RunWith(ConcordionRunner.class)
public class AnchorsTest {
    // TODO

}
