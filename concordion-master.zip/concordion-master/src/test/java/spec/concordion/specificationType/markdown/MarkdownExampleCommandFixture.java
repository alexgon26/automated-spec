package spec.concordion.specificationType.markdown;

import org.concordion.integration.junit4.ConcordionRunner;
import org.junit.runner.RunWith;

@RunWith(ConcordionRunner.class)
public class MarkdownExampleCommandFixture extends MarkdownGrammarFixture {
}
