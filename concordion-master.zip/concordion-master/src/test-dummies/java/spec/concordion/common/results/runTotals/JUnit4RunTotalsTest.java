package spec.concordion.common.results.runTotals;

import org.concordion.integration.junit4.ConcordionRunner;
import org.junit.runner.RunWith;

@RunWith(ConcordionRunner.class) 
public class JUnit4RunTotalsTest {

	public String getSuccessString() {
		return "Success";
	}

}
