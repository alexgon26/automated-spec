package org.concordion.api;

public enum SourceType {
    SPECIFICATION,
    RESOURCE;
}
