package spec.concordion.common.command.verifyRows.results;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.concordion.integration.junit4.ConcordionRunner;
import org.junit.runner.RunWith;

import test.concordion.TestRig;

@RunWith(ConcordionRunner.class)
public class MissingRowsTest {
    private List<Person> people = new ArrayList<Person>();

    public void addPerson(String firstName, String lastName, int birthYear) {
        people.add(new Person(firstName, lastName, birthYear));
    }
    
    public String getOutputFragment(String inputFragment) {
        return new TestRig()
            .withFixture(this)
            .processFragment(inputFragment)
            .getXOMDocument()
            .query("//table").get(0)
            .toXML()
            .replaceAll("\u00A0", "&#160;");
    }
    
    public Collection<Person> getPeople() {
        return people;
    }
    
    class Person {
        
        public Person(String firstName, String lastName, int birthYear) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.birthYear = birthYear;
        }
        
        public String firstName;
        public String lastName;
        public int birthYear;
    }
}
