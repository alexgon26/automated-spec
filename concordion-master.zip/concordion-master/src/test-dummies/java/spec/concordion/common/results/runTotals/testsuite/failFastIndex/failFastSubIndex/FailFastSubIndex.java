package spec.concordion.common.results.runTotals.testsuite.failFastIndex.failFastSubIndex;

import org.concordion.api.FailFast;
import org.concordion.integration.junit4.ConcordionRunner;
import org.junit.runner.RunWith;

@RunWith(ConcordionRunner.class)
@FailFast
public class FailFastSubIndex {
}
