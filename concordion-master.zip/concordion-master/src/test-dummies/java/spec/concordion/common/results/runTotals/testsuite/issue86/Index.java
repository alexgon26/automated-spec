package spec.concordion.common.results.runTotals.testsuite.issue86;

import org.concordion.integration.junit4.ConcordionRunner;
import org.junit.runner.RunWith;

@RunWith(ConcordionRunner.class)
public class Index {
}
