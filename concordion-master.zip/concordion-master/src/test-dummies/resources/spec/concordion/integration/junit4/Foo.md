# Foo

Sample specification for JUnit4 example.