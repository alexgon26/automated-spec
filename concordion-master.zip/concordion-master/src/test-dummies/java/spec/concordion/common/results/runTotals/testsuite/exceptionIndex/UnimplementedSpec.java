package spec.concordion.common.results.runTotals.testsuite.exceptionIndex;

import org.concordion.integration.junit4.ConcordionRunner;
import org.junit.runner.RunWith;

@RunWith(ConcordionRunner.class)
@org.concordion.api.Unimplemented
public class UnimplementedSpec {
}
