package spec.concordion.common.results.runTotals.testsuite.failFastIndex.failFastSubIndex;

import org.concordion.api.Unimplemented;
import org.concordion.integration.junit4.ConcordionRunner;
import org.junit.runner.RunWith;

@RunWith(ConcordionRunner.class)
@Unimplemented
public class UnimplementedSpec {
}
